export const transactiondata = [
  {
    transactionid: 'U12342343',
    from: 'bilal',
    to: 'halal',
  },
  {
    transactionid: 'U123432343',
    from: 'bilal',
    to: 'halal',
  },
  {
    transactionid: 'U12344543',
    from: 'bilal',
    to: 'halal',
  },
  {
    transactionid: 'U1234543643',
    from: 'bilal',
    to: 'halal',
  },
  {
    transactionid: 'U12342343456',
    from: 'bilal',
    to: 'halal',
  },
];

export default transactiondata;
