export const accountdata = [
  {
    accountno: 'US342343',
    type: 'saving',
    balance: '1289',
  },
  {
    accountno: 'US342123',
    type: 'saving',
    balance: '12839',
  },
  {
    accountno: 'US841443',
    type: 'saving',
    balance: '19984',
  },
  {
    accountno: 'US242343',
    type: 'saving',
    balance: '15489',
  },
  {
    accountno: 'UK0982343',
    type: 'saving',
    balance: '15489',
  },
  {
    accountno: 'PK154643',
    type: 'saving',
    balance: '15489',
  },
  {
    accountno: 'JK24234543',
    type: 'saving',
    balance: '15489',
  },
  {
    accountno: 'FK2434343',
    type: 'saving',
    balance: '154s89',
  },
  {
    accountno: 'US0043443',
    type: 'saving',
    balance: '19984',
  },
  {
    accountno: 'US242343',
    type: 'saving',
    balance: '15489',
  },
  {
    accountno: 'UK82343',
    type: 'saving',
    balance: '15489',
  },
];

export default accountdata;
