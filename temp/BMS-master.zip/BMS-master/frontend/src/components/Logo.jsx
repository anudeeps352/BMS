import React from 'react';
import logo from '../assets/images/bankcard.svg';

const Logo = () => {
  return <img src={logo} alt="BMS" className="logo"></img>;
};

export default Logo;
