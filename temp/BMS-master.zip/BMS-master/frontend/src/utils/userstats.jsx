const userstats = [
  {
    username: 'JOHN',
  },
  {
    phone: 'S8086754345',
  },
  {
    age: '40',
  },
];

export default userstats;
